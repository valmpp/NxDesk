@echo off
chcp 65001 >nul
title NxDesk Portable - Modo Visor (Conectar a Otro Equipo)
echo ==============================================================================
echo       👁️  NxDesk Portable — Modo Visor (Conectar a Equipo Remoto)
echo ==============================================================================
echo.
set /p TARGET="Ingrese el ID AnyDesk (ej. 111-222-333) o la IP del equipo remoto (ej. 192.168.1.50:5050): "

echo.
if "%TARGET%"=="" (
    echo Iniciando Dashboard en modo buscador...
    echo Abriendo http://localhost:5051 ...
    timeout /t 2 >nul
    start "" http://localhost:5051
    "%~dp0nxdesk-client.exe" --port 5051
) else (
    echo Conectando hacia: %TARGET% ...
    timeout /t 2 >nul
    start "" http://localhost:5051
    "%~dp0nxdesk-client.exe" --connect %TARGET% --port 5051
)
pause
