@echo off
chcp 65001 >nul
title NxDesk Portable - Servidor Central de Señalización (Puerto 5000)
echo ==============================================================================
echo       🌐  NxDesk Portable — Servidor Central de Señalización
echo ==============================================================================
echo.
echo Iniciando servidor de salas en puerto 5000...
echo Permite la intermediación de conexiones por ID de 9 dígitos (AnyDesk Style).
echo.
echo Endpoint WebSocket: ws://0.0.0.0:5000/signalinghub
echo Endpoint Diagnóstico: http://localhost:5000/
echo.
echo Mantenga esta ventana abierta mientras haya sesiones activas.
echo ==============================================================================
echo.
"%~dp0nxdesk-server.exe"
pause
