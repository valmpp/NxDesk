@echo off
chcp 65001 >nul
title NxDesk Portable - Modo Anfitrión (Compartir Pantalla)
echo ==============================================================================
echo       🖥️  NxDesk Portable — Modo Anfitrión (Compartiendo Pantalla)
echo ==============================================================================
echo.
echo Iniciando nodo y captura de pantalla...
echo ID de este equipo: 111-222-333
echo El Web Dashboard se abrirá automáticamente en su navegador.
echo.
echo Enlace de acceso directo: http://localhost:5050
echo.
echo Presione Ctrl+C en esta ventana para detener la transmisión cuando termine.
echo ==============================================================================
echo.
timeout /t 2 >nul
start "" http://localhost:5050
"%~dp0nxdesk-client.exe" --share --port 5050 --id=111-222-333
pause
